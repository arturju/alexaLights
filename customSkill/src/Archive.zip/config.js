var deviceId = "220033000b47343432313031";
var accessToken = "da51fb9df5c254672f0476e51eb0efc12c9f1009";

module.exports.deviceId 	= deviceId;
module.exports.accessToken 	= accessToken;
